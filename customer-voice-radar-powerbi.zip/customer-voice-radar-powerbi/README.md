# 📡 Customer Voice Radar | Power BI Dashboard

**Turning scattered customer data into a clear story: what the problem is, why it happens, what it costs, and what to do next.**

![Power BI](https://img.shields.io/badge/Power%20BI-F2C811?style=flat&logo=powerbi&logoColor=black)
![DAX](https://img.shields.io/badge/DAX-31%20Measures-1F7A8C?style=flat)
![Python](https://img.shields.io/badge/Python-Pandas-3776AB?style=flat&logo=python&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-SQLite-003B57?style=flat&logo=sqlite&logoColor=white)
![Google Colab](https://img.shields.io/badge/Google%20Colab-F9AB00?style=flat&logo=googlecolab&logoColor=white)

> Specialized challenge **"Data to Impact"** · GDGoC · Data Science & Engineering track · Team 3 · November 2026

---

## 🖼️ Dashboard Preview

### 1. Overview — *Where do we stand?*
![Overview](screenshots/01_overview.png)

### 2. Voice of Customer — *What is the problem?*
![Voice of Customer](screenshots/02_voice_of_customer.png)

### 3. Root Cause — *Why does it happen, and what does it cost?*
![Root Cause](screenshots/03_root_cause.png)

### 4. Early Warning — *Who is about to leave?*
![Early Warning](screenshots/04_early_warning.png)

### 5. Data Quality — *Can we trust the numbers?*
![Data Quality](screenshots/05_data_quality.png)

---|---|
| ![Overview](screenshots/01_overview.png) | ![Early Warning](screenshots/04_early_warning.png) |

---

## 🎯 The Problem

An e-commerce store had its data split across **8 separate files** (customers, products, suppliers, warehouses, orders, order items, reviews, inventory) with missing values, duplicates and logical errors. The store could not tell **which problems repeat, why they happen, or how much they cost**.

Star ratings alone were not enough: ratings barely changed with delivery delays (3.90 vs 3.77), while **text analysis** revealed that delivery is the #2 complaint topic.

---

## 🧭 Dashboard Pages

The report answers four questions in order, plus a data quality page.

| # | Page | Question it answers | Key visuals |
|---|---|---|---|
| 1 | **Overview** | Where do we stand? | 6 KPI cards, monthly sales trend, orders by status (donut), sales by city |
| 2 | **Voice of Customer** | What is the problem? | Complaint topics, sentiment per topic, overall sentiment |
| 3 | **Root Cause** | Why does it happen, and what does it cost? | Late delivery % by city, rating by delivery time, warehouse performance |
| 4 | **Early Warning** | Who is about to leave? | Anomalies by type & severity, Customer Health Score vs revenue, at-risk customer list |
| 5 | **Data Quality** | Can we trust the numbers? | Rows & missing values before/after cleaning, review anomalies, cleaning log |

Slicers (year, sales channel, city) are **synced across all pages**.

---

## 💡 Key Insights

| Insight | Number |
|---|---|
| Orders / net sales | **1,400** orders · **904,636 SAR** |
| Late deliveries (more than 6 days) | **23.8%** · highest in Abha (**37.1%**) and Jazan (**29.3%**) |
| Top complaint topics (negative text) | Quality (**152**) · Delivery (**132**) |
| Cost of orders with complaints | **97,703 SAR** |
| Customers at risk of leaving | **27** customers · **43,193 SAR** revenue |
| Anomalies detected | **1,328** (e.g. 424 reviews dated before their order) |

**Recommendations:** fix delivery in Abha & Jazan · contact at-risk customers · review the most-complained products · fix date capture in the system · combine text analysis with star ratings · require approval for discounts above 50%.

---

## ❤️ Customer Health Score

A 0–100 score per customer that combines four signals:

```
Health Score = 30 × Rating + 25 × Review Tone + 25 × On-time Delivery + 20 × Retention
```

| Score | Status |
|---|---|
| 75–100 | 🟢 Healthy |
| 50–74 | 🟡 Watch |
| below 50 | 🔴 At risk |

---

## 🗂️ Data Model

Star schema built for Power BI:

| Table | Grain | Rows |
|---|---|---|
| `FactOrders` | one order | 1,400 |
| `FactReviews` | one review | 850 |
| `ReviewTopics` | one topic of a review | 1,078 |
| `DimCustomer` | one customer + health score | 501 |
| `DimDate` | one day | calendar |
| `Anomalies` | one detected anomaly | 1,328 |
| `DataQuality` · `CleaningLog` | cleaning documentation | — |

Sample DAX measures:

```DAX
Late % = DIVIDE ( [Late Orders], [Shipped Orders] )

Complaint Cost = CALCULATE ( [Total Sales], FactOrders[has_complaint] = 1 )

Revenue at Risk =
CALCULATE ( SUM ( DimCustomer[revenue_sar] ), DimCustomer[health_band] = "معرّض للخسارة" )
```

---

## 🛠️ Tools

| Tool | Used for |
|---|---|
| **Power BI Desktop** | Data model, relationships, 31 DAX measures, 5-page interactive report |
| **Python (Pandas) · Google Colab** | Cleaning, merging, text analysis, anomaly detection, health score |
| **SQL (SQLite)** | KPI and complaint queries |

---

## 📁 Repository Structure

```
customer-voice-radar-powerbi/
├── dashboard/                     # Power BI project (open CustomerVoiceRadar.pbip)
│   ├── CustomerVoiceRadar.pbip
│   ├── CustomerVoiceRadar.Report/
│   └── CustomerVoiceRadar.SemanticModel/
├── data/
│   └── Dashboard_Data.xlsx        # model tables used by the dashboard
├── screenshots/                   # one image per dashboard page
└── theme/
    └── CustomerVoiceRadar_Theme.json
```

### ▶️ How to open
1. Download or clone the repository.
2. Open `dashboard/CustomerVoiceRadar.pbip` in **Power BI Desktop** (the data is embedded in the project).
3. Click **Refresh** if asked.
4. Optional: install the free **Amiri** font for the Arabic titles.

---

## 👥 Team & My Role

This was a team project (Team 3). **My role: Power BI dashboard designer**, responsible for the data model, DAX measures, report design, and bringing the team's results together in the dashboard.

| Member | Role |
|---|---|
| **Wajd Al Luhaybi** | Dashboard design (Power BI) |
| Aryam Salem | Data engineering & cleaning |
| Ruba Alomari | SQL analysis |
| Wasan Alotaibi | Text analysis |
| Shahad Alshehri | Quality assurance & report |

---

## 📬 Contact

**Wajd Al Luhaybi** · Computer Science student · Data Analysis

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0A66C2?style=flat&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/wajd-al-luhaibi-9194a1396)
[![X](https://img.shields.io/badge/X-@wajd__cs-000000?style=flat&logo=x&logoColor=white)](https://x.com/wajd_cs)
[![GitHub](https://img.shields.io/badge/GitHub-wajd--cs-181717?style=flat&logo=github&logoColor=white)](https://github.com/wajd-cs)
